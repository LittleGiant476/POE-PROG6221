using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms.Design;

namespace Part_3_Prac
{
   // https://github.com/LittleGiant476/POE-PROG6221
   // Link to the repo in GitHub

    public partial class Form1 : Form
    {
        // Declared Variables to capture from the TextBoxes
        public string recname;

        public string choice;

        public int numIngri;

        public string ingriName;

        public string ingriDesc;

        public int ingriQuant;

        public int ingriCalo;

        public string ingriFoodGroup;

        public string ingriUnit;

        public string steps;
        ///////////////////////////////
        ///////////////////////////////
        ///////////////////////////////
        
        // Declared Lists to use everywhere in the code as functions share these lists 

        public List<string> Recipe;

        public List<string> ingriList;

        public List<string> ingriDescList;

        public List<int> ingriQuantList;

        public List<int> ingriCaloList;

        public List<string> recName;

        public List<int> newIngriQuantList;

        public List<string> stepsList;

        public List<string> recNameList;

        public List<string> ingriFoodGroupList;

        public List<string> ingriUnitList;


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {



        }
        // Menu Item
        private void option1ToolStripMenuItem_Click(object sender, EventArgs e) // The button/funtion to set the Recipe

        {
            MainLbl.Text = "Please Enter a name";
            recname = txb1.Text;
            recName.Add(recname);



            lbl2.Text = "Please Enter a number of ingredients ";
            numIngri = int.Parse(txb2.Text);

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) // The Button/Funtion to exit the application
        {
            this.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e) // The Function to show the Author: Me 
        {
            MessageBox.Show("Author: Ethan Matthews");
        }

        //////////////////// Big Main Buttons //////////////////////////////

        private void Btn1_Click_1(object sender, EventArgs e) // The button/funtion to set the Recipe
            // Big Main Button 
        {
            recName = new List<string>();
            MainLbl.Text = "Please Enter a name";
            recname = txb1.Text;
            recName.Add(recname);

            lbl2.Text = "Please Enter a number of ingredients ";
            int.TryParse(txb2.Text, out numIngri);

        }

        private void btnConfirmDisplay_Click_1(object sender, EventArgs e) // The button/funtion to enter ingridients and their values
        {

            ingriName = " ";

            MainLbl.Text = "Please enter the name of ingredient ";
            ingriName = txb1.Text; // Ingredient name
            ingriList.Add(ingriName);

            lbl2.Text = "Please enter a description of ingredient ";
            ingriDesc = txb2.Text; // Ingredient Description
            ingriDescList.Add(ingriDesc);
            recName.Add(ingriName);

            lbl3.Text = "Quantity";
            ingriQuant = int.Parse(txb3.Text); // Ingredient Quantity
            ingriQuantList.Add(ingriQuant);

            lbl4.Text = "Calories";
            ingriCalo = int.Parse(txb4.Text); // Calories as stated by the user
            ingriCaloList.Add(ingriCalo);

            lbl5.Text = "Units";
            ingriUnit = txb5.Text;
            ingriUnitList.Add(ingriUnit);

            lbl6.Text = "Food Group";
            ingriFoodGroup = txb6.Text; // A food group to be declared by the user
            ingriFoodGroupList.Add(ingriFoodGroup);

        }

        private void AddStepbtn_Click(object sender, EventArgs e) // The button/function to add a step
        {
            MainLbl.Text = "Please a description to the step you would want to add";
            steps = txb1.Text;

            stepsList.Add(steps);

        }

        private void btn2_Click(object sender, EventArgs e) // The button/funtion to select a Recipe to display
        {
            var message = string.Join(Environment.NewLine, recName);

            MessageBox.Show("Recipes to choose from" + message);

            MainLbl.Text = "Please select a recipe to display";
        }

        private void ConfirmDisplaybtn_Click(object sender, EventArgs e)// The button/funtion to confirm the display
        {

            if (txb1 != null)
            {
                var message = string.Join(Environment.NewLine, recname);

                MessageBox.Show("Recipes name" + message); // Display the name first 


                var message2 = string.Join(Environment.NewLine, ingriList);

                MessageBox.Show("Ingredients in this recipe" + message2); // Display the Ingredients

                var message3 = string.Join(Environment.NewLine, stepsList);

                MessageBox.Show("Steps to follow in this Recipe" + message3); // Display the steps

            }
            else
            {
                MessageBox.Show("Incorrect option selcted"); // If no resope was selected
            }

        }

        private void btn3_Click(object sender, EventArgs e) // The button/funtion to scale the recipe by a factor
        {
            MessageBox.Show("Factor the recipe by 1 -> to half the recipe" +
                "2 -> to double the recipe" +
                "3 -> to triple the recipe");

            int choice = int.Parse(txb1.Text);

            if (choice == 1) // scale by a factor of a half
            {

                foreach (var item in ingriQuantList)
                {
                    newIngriQuantList.Add(item / 2);
                }
            }
            else if (choice == 2) // scale by a factor of double
            {
                foreach (var item in ingriQuantList)
                {
                    newIngriQuantList.Add(item * 2);
                }

            }
            else if (choice == 3) // scale by a factor of triple
            {
                foreach (var item in ingriQuantList)
                {
                    newIngriQuantList.Add(item * 3);
                }

            }
            else
            {
                MessageBox.Show("Incorrect option selected"); // Incorect option was selected to scale
            }
        }

        private void ClearRecipeBtn_Click(object sender, EventArgs e) // The button/funtion to delete a recipe
        {
            MessageBox.Show("Please select a recipe to clear/delete");

            var message = string.Join(Environment.NewLine, recName);
            MessageBox.Show("Recipes to choose from " + message);

        }

       

        private void ConfirmClearBtn_Click(object sender, EventArgs e) // The button/funtion to confirm a deleting of a recipe
        {
            if (txb1 != null)
            {

                ingriList.Clear();
                ingriDescList.Clear();
                ingriCaloList.Clear();
                ingriQuantList.Clear();
                ingriFoodGroupList.Clear();
                ingriUnitList.Clear();
                stepsList.Clear();
                MessageBox.Show("Recipe cleared successfully "); // prompt the user the clearing is complete
            }
            else
            {
                MessageBox.Show("Incorrect recipe chosen"); // incorrect option was selected to clear a recipe
            }
            

        }

        private void SearchInsidebtn_Click(object sender, EventArgs e) // The button/funtion to search within a recipe
        {
            MessageBox.Show(" Names of ingredients, food groups and certain calories can be chosen within a recipe");
            string choice;
            MainLbl.Text = "Select what to search for within the recipe";

            choice = txb1.Text.ToString();
        }



        private void ConfirmSearchbtn_Click(object sender, EventArgs e) // The Button/function to confirm the searching within a recipe
        {
            List<string> stringListCalo = ingriCaloList.ConvertAll(x => x.ToString());
            if (txb1 != null)
            {

                if (stringListCalo.Contains(choice) || ingriList.Contains(choice) || ingriFoodGroup.Contains(choice)) // An OR statement to to cover all three options
                {
                    System.Collections.IList list = ingriCaloList;
                    for (int i = 0; i < list.Count; i++)
                    {
                        string t = (string)list[i];
                        MessageBox.Show(t, ToString());
                    }
                    foreach (var item in ingriList)
                    {
                        MessageBox.Show(item);
                    }
                }
                else
                {
                    MessageBox.Show("No recipe was entered to clear"); // If nothing was found within the three Lists
                }
            }

        }

        //////////////////////Menu Item Button Options//////////////////////////////


        private void displayRecipeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var message = string.Join(Environment.NewLine, recName);

            MessageBox.Show("Recipes to choose from" + message);

            MainLbl.Text = "Please select a recipe to display";

        }

        private void option1ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            recName = new List<string>();
            MainLbl.Text = "Please Enter a name";
            recname = txb1.Text;
            recName.Add(recname);

            lbl2.Text = "Please Enter a number of ingredients ";
            int.TryParse(txb2.Text, out numIngri);
        }

        private void addAnIngredientToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ingriName = " ";

            MainLbl.Text = "Please enter the name of ingredient ";
            ingriName = txb1.Text;
            ingriList.Add(ingriName);

            lbl2.Text = "Please enter a description of ingredient ";
            ingriDesc = txb2.Text;
            ingriDescList.Add(ingriDesc);
            recName.Add(ingriName);

            lbl3.Text = "Quantity";
            ingriQuant = int.Parse(txb3.Text);
            ingriQuantList.Add(ingriQuant);

            lbl4.Text = "Calories";
            ingriCalo = int.Parse(txb4.Text);
            ingriCaloList.Add(ingriCalo);

            lbl5.Text = "Units";
            ingriUnit = txb5.Text;
            ingriUnitList.Add(ingriUnit);

            lbl6.Text = "Food Group";
            ingriFoodGroup = txb6.Text;
            ingriFoodGroupList.Add(ingriFoodGroup);

        }

        private void factorTheRecipeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Factor the recipe by 1 -> to half the recipe" +
                "2 -> to double the recipe" +
                "3 -> to triple the recipe");

            int choice = int.Parse(txb1.Text);

            if (choice == 1)
            {

                foreach (var item in ingriQuantList)
                {
                    newIngriQuantList.Add(item / 2);
                }
            }
            else if (choice == 2)
            {
                foreach (var item in ingriQuantList)
                {
                    newIngriQuantList.Add(item * 2);
                }

            }
            else if (choice == 3)
            {
                foreach (var item in ingriQuantList)
                {
                    newIngriQuantList.Add(item * 3);
                }

            }
            else
            {
                MessageBox.Show("Incorrect option selected");
            }
        }

        private void clearARecipeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Please select a recipe to clear/delete");

            var message = string.Join(Environment.NewLine, recName);
            MessageBox.Show("Recipes to choose from " + message);

        }

        private void searchInsideARecipeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MessageBox.Show(" Names of ingredients, food groups and certain calories can be chosen within a recipe");
            string choice;
            MainLbl.Text = "Select what to search for within the recipe";

            choice = txb1.Text.ToString();
        }
    }


}

