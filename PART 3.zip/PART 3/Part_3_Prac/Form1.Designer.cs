﻿namespace Part_3_Prac
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            option1ToolStripMenuItem = new ToolStripMenuItem();
            displayRecipeToolStripMenuItem = new ToolStripMenuItem();
            addAnIngredientToolStripMenuItem = new ToolStripMenuItem();
            factorTheRecipeToolStripMenuItem = new ToolStripMenuItem();
            clearARecipeToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            searchInsideARecipeToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            MainLbl = new Label();
            txb1 = new TextBox();
            Btn1 = new Button();
            btn2 = new Button();
            lbl2 = new Label();
            txb2 = new TextBox();
            btnConfirmDisplay = new Button();
            txb3 = new TextBox();
            lbl3 = new Label();
            btn3 = new Button();
            AddStepbtn = new Button();
            txb4 = new TextBox();
            lbl4 = new Label();
            ClearRecipeBtn = new Button();
            SearchInsidebtn = new Button();
            ConfirmClearBtn = new Button();
            ConfirmSearchbtn = new Button();
            txb5 = new TextBox();
            txb6 = new TextBox();
            lbl5 = new Label();
            lbl6 = new Label();
            ConfirmDisplaybtn = new Button();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(802, 24);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { option1ToolStripMenuItem, displayRecipeToolStripMenuItem, addAnIngredientToolStripMenuItem, factorTheRecipeToolStripMenuItem, clearARecipeToolStripMenuItem, exitToolStripMenuItem, searchInsideARecipeToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // option1ToolStripMenuItem
            // 
            option1ToolStripMenuItem.Name = "option1ToolStripMenuItem";
            option1ToolStripMenuItem.Size = new Size(190, 22);
            option1ToolStripMenuItem.Text = "Create a Recipe";
            option1ToolStripMenuItem.Click += option1ToolStripMenuItem_Click_1;
            // 
            // displayRecipeToolStripMenuItem
            // 
            displayRecipeToolStripMenuItem.Name = "displayRecipeToolStripMenuItem";
            displayRecipeToolStripMenuItem.Size = new Size(190, 22);
            displayRecipeToolStripMenuItem.Text = "Display Recipe";
            displayRecipeToolStripMenuItem.Click += displayRecipeToolStripMenuItem_Click;
            // 
            // addAnIngredientToolStripMenuItem
            // 
            addAnIngredientToolStripMenuItem.Name = "addAnIngredientToolStripMenuItem";
            addAnIngredientToolStripMenuItem.Size = new Size(190, 22);
            addAnIngredientToolStripMenuItem.Text = "Add an Ingredient";
            addAnIngredientToolStripMenuItem.Click += addAnIngredientToolStripMenuItem_Click;
            // 
            // factorTheRecipeToolStripMenuItem
            // 
            factorTheRecipeToolStripMenuItem.Name = "factorTheRecipeToolStripMenuItem";
            factorTheRecipeToolStripMenuItem.Size = new Size(190, 22);
            factorTheRecipeToolStripMenuItem.Text = "Factor the Recipe";
            factorTheRecipeToolStripMenuItem.Click += factorTheRecipeToolStripMenuItem_Click;
            // 
            // clearARecipeToolStripMenuItem
            // 
            clearARecipeToolStripMenuItem.Name = "clearARecipeToolStripMenuItem";
            clearARecipeToolStripMenuItem.Size = new Size(190, 22);
            clearARecipeToolStripMenuItem.Text = "Clear a Recipe";
            clearARecipeToolStripMenuItem.Click += clearARecipeToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(190, 22);
            exitToolStripMenuItem.Text = "&Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // searchInsideARecipeToolStripMenuItem
            // 
            searchInsideARecipeToolStripMenuItem.Name = "searchInsideARecipeToolStripMenuItem";
            searchInsideARecipeToolStripMenuItem.Size = new Size(190, 22);
            searchInsideARecipeToolStripMenuItem.Text = "Search inside a Recipe";
            searchInsideARecipeToolStripMenuItem.Click += searchInsideARecipeToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(180, 22);
            aboutToolStripMenuItem.Text = "&About";
            aboutToolStripMenuItem.Click += aboutToolStripMenuItem_Click;
            // 
            // MainLbl
            // 
            MainLbl.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            MainLbl.Location = new Point(251, 74);
            MainLbl.Name = "MainLbl";
            MainLbl.Size = new Size(275, 22);
            MainLbl.TabIndex = 2;
            MainLbl.Text = "Place Holder Text";
            MainLbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txb1
            // 
            txb1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txb1.Location = new Point(251, 100);
            txb1.Name = "txb1";
            txb1.Size = new Size(275, 23);
            txb1.TabIndex = 3;
            // 
            // Btn1
            // 
            Btn1.Location = new Point(39, 74);
            Btn1.Name = "Btn1";
            Btn1.Size = new Size(188, 39);
            Btn1.TabIndex = 4;
            Btn1.Text = "Create a Recipe";
            Btn1.UseVisualStyleBackColor = true;
            Btn1.Click += Btn1_Click_1;
            // 
            // btn2
            // 
            btn2.Location = new Point(39, 134);
            btn2.Name = "btn2";
            btn2.Size = new Size(114, 35);
            btn2.TabIndex = 5;
            btn2.Text = "Display Recipe";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click;
            // 
            // lbl2
            // 
            lbl2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbl2.Location = new Point(251, 126);
            lbl2.Name = "lbl2";
            lbl2.Size = new Size(275, 22);
            lbl2.TabIndex = 6;
            lbl2.Text = "Place Holder Text";
            lbl2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txb2
            // 
            txb2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txb2.Location = new Point(251, 151);
            txb2.Name = "txb2";
            txb2.Size = new Size(275, 23);
            txb2.TabIndex = 7;
            // 
            // btnConfirmDisplay
            // 
            btnConfirmDisplay.Location = new Point(401, 310);
            btnConfirmDisplay.Name = "btnConfirmDisplay";
            btnConfirmDisplay.Size = new Size(126, 39);
            btnConfirmDisplay.TabIndex = 8;
            btnConfirmDisplay.Text = "Add an Ingredient";
            btnConfirmDisplay.UseVisualStyleBackColor = true;
            btnConfirmDisplay.Click += btnConfirmDisplay_Click_1;
            // 
            // txb3
            // 
            txb3.Location = new Point(251, 203);
            txb3.Name = "txb3";
            txb3.Size = new Size(127, 23);
            txb3.TabIndex = 9;
            // 
            // lbl3
            // 
            lbl3.Location = new Point(251, 177);
            lbl3.Name = "lbl3";
            lbl3.Size = new Size(127, 23);
            lbl3.TabIndex = 10;
            lbl3.Text = "Place Holder Text";
            lbl3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btn3
            // 
            btn3.Location = new Point(39, 191);
            btn3.Name = "btn3";
            btn3.Size = new Size(188, 38);
            btn3.TabIndex = 11;
            btn3.Text = "Factor The Recipe";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // AddStepbtn
            // 
            AddStepbtn.Location = new Point(251, 310);
            AddStepbtn.Name = "AddStepbtn";
            AddStepbtn.Size = new Size(127, 39);
            AddStepbtn.TabIndex = 12;
            AddStepbtn.Text = "Add a step";
            AddStepbtn.UseVisualStyleBackColor = true;
            AddStepbtn.Click += AddStepbtn_Click;
            // 
            // txb4
            // 
            txb4.Location = new Point(401, 203);
            txb4.Name = "txb4";
            txb4.Size = new Size(126, 23);
            txb4.TabIndex = 13;
            // 
            // lbl4
            // 
            lbl4.Location = new Point(401, 177);
            lbl4.Name = "lbl4";
            lbl4.Size = new Size(126, 23);
            lbl4.TabIndex = 14;
            lbl4.Text = "Place Holder Text";
            lbl4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ClearRecipeBtn
            // 
            ClearRecipeBtn.Location = new Point(39, 251);
            ClearRecipeBtn.Name = "ClearRecipeBtn";
            ClearRecipeBtn.Size = new Size(114, 39);
            ClearRecipeBtn.TabIndex = 15;
            ClearRecipeBtn.Text = "Clear a recipe";
            ClearRecipeBtn.UseVisualStyleBackColor = true;
            ClearRecipeBtn.Click += ClearRecipeBtn_Click;
            // 
            // SearchInsidebtn
            // 
            SearchInsidebtn.Location = new Point(39, 310);
            SearchInsidebtn.Name = "SearchInsidebtn";
            SearchInsidebtn.Size = new Size(114, 40);
            SearchInsidebtn.TabIndex = 16;
            SearchInsidebtn.Text = "Search inside a recipe";
            SearchInsidebtn.UseVisualStyleBackColor = true;
            SearchInsidebtn.Click += SearchInsidebtn_Click;
            // 
            // ConfirmClearBtn
            // 
            ConfirmClearBtn.Location = new Point(155, 251);
            ConfirmClearBtn.Name = "ConfirmClearBtn";
            ConfirmClearBtn.Size = new Size(72, 39);
            ConfirmClearBtn.TabIndex = 17;
            ConfirmClearBtn.Text = "Confirm";
            ConfirmClearBtn.UseVisualStyleBackColor = true;
            ConfirmClearBtn.Click += ConfirmClearBtn_Click;
            // 
            // ConfirmSearchbtn
            // 
            ConfirmSearchbtn.Location = new Point(155, 310);
            ConfirmSearchbtn.Name = "ConfirmSearchbtn";
            ConfirmSearchbtn.Size = new Size(72, 40);
            ConfirmSearchbtn.TabIndex = 18;
            ConfirmSearchbtn.Text = "Confirm";
            ConfirmSearchbtn.UseVisualStyleBackColor = true;
            ConfirmSearchbtn.Click += ConfirmSearchbtn_Click;
            // 
            // txb5
            // 
            txb5.Location = new Point(251, 260);
            txb5.Name = "txb5";
            txb5.Size = new Size(127, 23);
            txb5.TabIndex = 19;
            // 
            // txb6
            // 
            txb6.Location = new Point(401, 260);
            txb6.Name = "txb6";
            txb6.Size = new Size(126, 23);
            txb6.TabIndex = 20;
            // 
            // lbl5
            // 
            lbl5.Location = new Point(251, 229);
            lbl5.Name = "lbl5";
            lbl5.Size = new Size(127, 23);
            lbl5.TabIndex = 21;
            lbl5.Text = "Place Holder Text";
            lbl5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl6
            // 
            lbl6.Location = new Point(401, 229);
            lbl6.Name = "lbl6";
            lbl6.Size = new Size(126, 23);
            lbl6.TabIndex = 22;
            lbl6.Text = "Place Holder Text";
            lbl6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ConfirmDisplaybtn
            // 
            ConfirmDisplaybtn.Location = new Point(155, 134);
            ConfirmDisplaybtn.Name = "ConfirmDisplaybtn";
            ConfirmDisplaybtn.Size = new Size(72, 35);
            ConfirmDisplaybtn.TabIndex = 23;
            ConfirmDisplaybtn.Text = "Confirm";
            ConfirmDisplaybtn.UseVisualStyleBackColor = true;
            ConfirmDisplaybtn.Click += ConfirmDisplaybtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(802, 448);
            Controls.Add(ConfirmDisplaybtn);
            Controls.Add(lbl6);
            Controls.Add(lbl5);
            Controls.Add(txb6);
            Controls.Add(txb5);
            Controls.Add(ConfirmSearchbtn);
            Controls.Add(ConfirmClearBtn);
            Controls.Add(SearchInsidebtn);
            Controls.Add(ClearRecipeBtn);
            Controls.Add(lbl4);
            Controls.Add(txb4);
            Controls.Add(AddStepbtn);
            Controls.Add(btn3);
            Controls.Add(lbl3);
            Controls.Add(txb3);
            Controls.Add(btnConfirmDisplay);
            Controls.Add(txb2);
            Controls.Add(lbl2);
            Controls.Add(btn2);
            Controls.Add(Btn1);
            Controls.Add(txb1);
            Controls.Add(MainLbl);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem option1ToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private Label MainLbl;
        private TextBox txb1;
        private Button Btn1;
        private Button btn2;
        private Label lbl2;
        private TextBox txb2;
        private Button btnConfirmDisplay;
        private TextBox txb3;
        private Label lbl3;
        private Button btn3;
        private Button AddStepbtn;
        private TextBox txb4;
        private Label lbl4;
        private ToolStripMenuItem displayRecipeToolStripMenuItem;
        private Button ClearRecipeBtn;
        private Button SearchInsidebtn;
        private Button ConfirmClearBtn;
        private Button ConfirmSearchbtn;
        private TextBox txb5;
        private TextBox txb6;
        private Label lbl5;
        private Label lbl6;
        private Button ConfirmDisplaybtn;
        private ToolStripMenuItem addAnIngredientToolStripMenuItem;
        private ToolStripMenuItem factorTheRecipeToolStripMenuItem;
        private ToolStripMenuItem clearARecipeToolStripMenuItem;
        private ToolStripMenuItem searchInsideARecipeToolStripMenuItem;
    }
}